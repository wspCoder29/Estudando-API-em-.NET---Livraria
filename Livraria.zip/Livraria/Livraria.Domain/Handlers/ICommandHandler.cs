﻿namespace Livraria.Domain.Handlers
{
    public interface ICommandHandler<T1, T2, T3>
    {
    }
}
﻿namespace Livraria.Infra.Interfaces.Commands
{
    public interface ICommandPadrao
    {
        bool ValidarCommad();
    }
}
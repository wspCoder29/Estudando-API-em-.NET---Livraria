﻿namespace Livraria.Infra.Settings
{
    public class AppSettings
    {
        public string ConnectionString { get; set; }
    }
}